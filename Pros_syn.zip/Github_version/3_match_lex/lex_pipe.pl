#!/usr/bin/perl
# TB, Jan 2022
# This script is matching with the lexicon. It's called from pipeline.pl


# $XFST = 'xfst -f script.xfst';
# system($XFST);
# The full path has to be defined
# The script is called, which runs the testsuite on lexicon 1 (p-form/s-form) and saves
# the results in results.txt

# ###############################################################
# ===============================================================
print "\n3.2. Calling script_synphon_pipe.xfst:\n";
print "======================================================\n";
#print ">> calls up lexicon synphon.txt: upper-syn, lower-phon (syll only)\n";
#print ">> applys up testsuite.txt, match pform against sform \n";
#print ">> Output: results_syn.txt\n";
#print "======================================================\n";
#print "--> Press enter to continue\n";

#$input = <STDIN>;

$Path = '/Applications/fst64/bin/xfst';
$Script= '3_match_lex/script_synphon_pipe.xfst';

system("$Path -f $Script");



# ###############################################################
# ===============================================================
print "\n3.3. Establishing the s-string (exhaustive parse)\n";
print "======================================================\n";
#print ">> Creates two hashes: %Silbe: SyllID-value, %Silbenzahl: upper-SyllNr\n";
#print ">> A combination of the two is used to exhaustively match the p-string (including alternatives) \n";
#print ">> Output: s_string.txt (includes all possible s-strings)\n";
#print "======================================================\n";


# Processing the results of matching the testsuite agains the lexicon: Identifying upper
# and lower strings, the string ID and the number of syllables in two hashes:
# %Silbe stores the Syllable-number as key and an existing upper string in an array as value
# %Silbenzahl stores the upper string as a key and the number of syllables this string has as value

open(FILE3, "3_match_lex/results_syn.txt");  

my $count_syll = 0;
$next = "n";

%Silbe = {};
%Silbenzahl = {};

while (defined(my $t = <FILE3>)) {
	chomp($t);
	foreach $line ($t){
		$count_string_syll ++;
		if ($line =~ />> Switch/){
			$count_string_syll = -1;
			$count_syll++;
			$next = "n";
		}
		if ($line eq ""){
			$next = "lower";
			$count_string_syll = $count_string_syll-1;
		}
		if (($line ne "") && ($line !~ />> Switch/) && ($next eq "lower")){
			$lower = $line;
			$next = "upper";
			$count_string_syll = $count_string_syll-1;
		}
		elsif (($line ne "") && ($line !~ />> Switch/) && ($next eq "upper")){
			if ($line ne "???"){
				$upper = $line;
				push @{$Silbe{$count_syll}}, $upper;
				if (!(exists $Silbenzahl{$upper})){
					$Silbenzahl{$upper} = $count_string_syll;
				}
			}
			$next = "n";
		}
	}
}

close(FILE3);

# This part finds the very "last" valid string and attaches a # to it. Needed so ones knows 
# the "end" in the pattern matching below.
@size= keys %Silbe;
$length_Silbe = @size;

$count_key = 0;
foreach my $key (sort { $a <=> $b} keys %Silbe){	
	$count_key ++;
	if ($count_key == $length_Silbe){
		# print "$key : $Silbe{$key}[0]\n";
		# retrieve that element, combine it with a hash, put it back
		$last_word = $Silbe{$key}[0]."#";
		pop(@{$Silbe{$key}});
		push @{$Silbe{$key}}, $last_word;
		# print "$key : $Silbe{$key}[0]\n";
	}
}


# This part combines the possible strings. It takes the value(s) of the first key of %Silbe and passes them on to 
# %Silbenzahl. The number of the syllable (key in %Silbe) and the number of syllables (value in %Silbenzahl) added
# up gives you the next key in %Silbe. If this does not exist, then the string is a mismatch = dead. If a value is found
# then the string continues to loop, until the word with the #-sign is reached: then the string is at an end.

# There are 3 subroutines: 
# Subroutine &Retrieve is the outer one, which ensures that the sentence actually only ever starts with
# (one of) the first word(s).

# Subroutine &Continue then allows for the looping. There are three possibilities:
# 1. If there is only one possibility (length of value array = 1), then the loop goes to the next word
# 2. If there are more possbilities (length > 1), each possibility is processed separately (subroutine &Branch)
# 3. If the last word (marked by #) is found, the string is saved and the loop jumps back to &Retrieve

# Subroutine &Branch is only there if there  is more than one option in the middle of the clause
# Here, the original string is "petrified" and the routine continues from there for all possibilities
# until a # is reached. Then it prints out the string and continues with the next possibility, until 
# all of them are exhausted. Then it continues with &Retrieve



# Always start with key=1 --> first word(s)
$key = 1;


open(OUTPUT4, "> 3_match_lex/s_string.txt"); 
$break = 0;

&Retrieve();

$string = "";

sub Retrieve {
	$break ++;
	foreach $element (@{$Silbe{$key}}){
		#print ">>$element: $Silbenzahl{$element}\n";
		$sa = $Silbenzahl{$element};
		# print ">> Start: $element\n";
		$string = "#$element ";
		&Continue($string, $sa, $key);
	}	
}

sub Continue {
	$string = $_[0];
	$sa = $_[1];
	$old_key = $_[2];
	$new_key = $old_key + $sa;	
	$length = @{$Silbe{$new_key}};
	if (($length == 1) && ($Silbe{$new_key}[0] !~ /#/)){
		$string .= "$Silbe{$new_key}[0] ";
		$sa = $Silbenzahl{$Silbe{$new_key}[0]};
		# print "$string  $sa\n";
		&Continue($string, $sa, $new_key);
	}
	elsif (($length > 1) && ($Silbe{$new_key}[0] !~ /#/)){
		$count = -1;
		foreach $possib (@{$Silbe{$new_key}}){
			$count ++;
			$str_branch = $string;
			$new_b_key = $new_key;
			$str_branch .= "$Silbe{$new_b_key}[$count] ";
			$sa = $Silbenzahl{$Silbe{$new_b_key}[$count]};
			# print "++ $str_branch $sa\n";
			&Branch($str_branch, $sa, $new_b_key);
		}
	}
	elsif ($Silbe{$new_key}[0] =~ /#/){
		#$string =~ s/#//;
		# print ">> End\n";
		$string .= "$Silbe{$new_key}[0]";
		$string =~ s/#//g;
		print OUTPUT4 "$string\n";
		$string = "";
		$new_key = 0;
	}
	
}


sub Branch {
	$str_branch = $_[0];
	$sa = $_[1];
	$old_key = $_[2];
	$new_b_key = $old_key + $sa;	
	$length = @{$Silbe{$new_b_key}};
	if (($length == 1) && ($Silbe{$new_b_key}[0] !~ /#/)){
		$str_branch .= "$Silbe{$new_b_key}[0] ";
		$sa = $Silbenzahl{$Silbe{$new_b_key}[0]};
		&Branch($str_branch, $sa, $new_b_key);
	}
	elsif ($Silbe{$new_b_key}[0] =~ /#/){
		$str_branch .= "$Silbe{$new_b_key}[0]";
		$str_branch =~ s/#//g;
		print OUTPUT4 "$str_branch\n";
		$str_branch = "";
		$new_b_key = 0;
	}
}

close(OUTPUT4);


# ###############################################################
print "\n3.4. Getting the p-form information out of the lexicon\n";
print "======================================================\n";
#print ">> The s_string is put into testsuite format in testsuite2.txtn";
#print ">> script_phonphon_pipe.xfst is called and loads phonphon.txt as lexicon: upper-sform, lower-all phon. information \n";
#print ">> testsuite2.txt is applied down\n";
#print ">> Output: results_phon.txt\n";
#print "======================================================\n";


# Processing the results of matching the testsuite agains the lexicon
open(FILE4, "3_match_lex/s_string.txt");  
open(OUTPUT5, "> 3_match_lex/testsuite2.txt");
$count_lines = 0;

while (defined(my $t = <FILE4>)) {
	chomp($t);
	foreach $line ($t){
		$count ++;
		print OUTPUT5 ">> Line $count\n";
		@sforms = split(" ",$line);
		foreach $form (@sforms){
			print OUTPUT5 "$form\n";
		}
	}
}
print OUTPUT5 ">> Line\n";

close(FILE4);
close(OUTPUT5);

# This accesses all the relevant p-form information
$Path = '/Applications/fst64/bin/xfst';
$Script= '3_match_lex/script_phonphon_pipe.xfst';

system("$Path -f $Script");



