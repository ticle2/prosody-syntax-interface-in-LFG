#!/usr/bin/perl
# TB, Jan 2022
# This script is the main coordinator for the computational implementation of the 
# prosody-syntax interface in LFG. It calls up the different subprocesses in the folders 1-5

use Statistics::R;


# ###############################################################
# ===============================================================
print "\n1. Working on the speech signal: 1\_extract\_signal\n";
print "======================================================\n";
# print ">>> Press enter to continue\n";
# $input = <STDIN>;


# ###############################################################
# ===============================================================
print "\n1.1. Extract information from the speech signal:\n";
print "======================================================\n";
print ">> (duration), time is normalized, 5 intervals per syllable (unique number through signal), F0mean,  F0 is converted to semitones.\n";
print ">> Script: praat_extract_pipe.praat\n";
print ">> Output: 1_extract_signal/table_norm_st.txt\n";
print "======================================================\n";
print ">>> Press enter to continue and then select a speech signal\n";

# $input = <STDIN>;


# Calling up praat_info.praat
$filename = $ARGV[0];

# the path to Praat, the script name, and the filename have to be stored in an array
$Path = '/Applications/Praat.app/Contents/MacOS/Praat';
$Script= '1_extract_signal/praat_extract_pipe.praat';

@cmd = ($Path, $Script, $filename);

# This lets the user select a speech signal (the .wav file), which is then further processed by the Praat Script
# in the folder 1_extract_signal
system(@cmd);


# ###############################################################
# ===============================================================
print "\n1.2. Resort extracted information from the speech signal\n";
print "======================================================\n";
print ">> Clean up: split and store info from file name, replace 'undefined' with NA \n";
print ">> Output: 1_extract_signal/table_norm_st_res.txt\n";
print "======================================================\n";
print "--> Press enter to continue\n";

$input = <STDIN>;

# This script resorts output from Praat scripting for further analysis.
###### Resorting table_norm_st.txt which contains 5 f0 measures/syllable, unique
# time markers, and semitones, into a file where the file name is split and file is cleaned

$resort = 'perl 1_extract_signal/resort_pipe.pl';

system($resort);


print ">>> Done with 1_extract_signal\n";


# ###############################################################
# ===============================================================
print "\n2. Determing relevant measures for the pitch evaluation: 2\_pitch \n";
print "======================================================\n";
print "This section determines the different pitch values (mins and maxs),\n";
print "and where the measure was taken in the syllable (early, mid, late).\n";
print "It takes out all outliers, and gets the residuals,\n";
print "and encodes the scale of the lead and tail slopes.\n";
print ">>> Press enter to continue\n";
$input = <STDIN>;


$pitch = 'perl 2_pitch/pitch_pipe.pl';
system($pitch);


# use this for a quick check whether everything worked
#foreach $key (sort { $a <=> $b} keys %store) {
#	if ($store{$key}[5] ne "NA"){
#		print "$key\t$store{$key}[0]\t$store{$key}[1]\t$store{$key}[2]\t$store{$key}[3]\t resid: $store{$key}[4]\t Min/Max: $store{$key}[5]\t Slope-to: $store{$key}[6]\t Slope-from: $store{$key}[7] \n";	
#	}
#}

print ">>> Done with 2_pitch\n";



# ###############################################################
# ===============================================================
print "\n3. Lexical matching: 3_match_lex \n";
print "======================================================\n";
print "This section concatenates the syllables and then matches them against an\n";
print "xfst lexicon, which contains both the p-forms and s-forms. The program successively\n";
print "matches the strings against each other until all substrings can be parsed.\n";
print "The final output is the s-string.\n";
print ">>> Press enter to continue\n";
$input = <STDIN>;



# ###############################################################
# ===============================================================
print "\n3.1. Creating a testsuite for lexical matching:\n";
print "======================================================\n";
# print ">> concatenates syllables one by one, from one to first-final (i.e., all combis)\n";
# print ">> Output: 3_lex_match/testsuite.txt \n";
# print ">> Sub-program lex.pl to do xfst work \n";
# print "======================================================\n";
# print "--> Press enter to continue\n";

# This section simlpy reads out all the syllable values into an array, which is then used to
# create the testsuite
$SyllID = 0;
@syllables = (); # Use in Section 3.1 for testsuite

open(FILE2, "1_extract_signal/table_norm_st_res.txt");


while (defined(my $t = <FILE2>)) {
	chomp($t);
	foreach $line ($t){
		if (($line !~ "SubIntNr") & ($line !~ "Pause")){
			@line_split = split(/\t/, $line);
			$syllNr = $line_split[0];
			$syll = $line_split[1];  # string
			if ($syllNr ne $SyllID){
				push(@syllables, $syll);
				$SyllID = $syllNr;
			}
		}	
	}
}
close(FILE2);

## working on lexicon
## This part takes the syllable array and starting from the left concatenates them bit by bit
## and puts them in a testsuite, i.e.: das, das.de6, das.de6.pa6 .... 
## Every time the leftmost syllable changes, a "Switch" is included to make later processing easier
## in the testsuite 

open(OUTPUT3, "> 3_match_lex/testsuite.txt");
$count_syll = -1;
$length_syll = @syllables;

foreach $syll (@syllables){
	$count_syll ++;
	$count_left = $count_syll;
	$start = $syll;
	$nr = $count_syll+1;
	print OUTPUT3 ">> Switch.$nr\n$start\n";
	while ($count_left < ($length_syll-1)){
		$count_left ++;
		$start .= ".$syllables[$count_left]";
		print OUTPUT3 "$start\n";
		$start = $start;
	}
}

close(OUTPUT3);



$lexicon = 'perl 3_match_lex/lex_pipe.pl';

system($lexicon);

#print "\n\nOUTPUT 1: 3_match_lex/s_string.txt\n"; 
#print "OUTPUT 2: p-form info: 3_lex_match/results_phon.txt\n";
print ">>> Done with 3_match_lex\n";
print ">>> Press enter to continue\n";
# $input = <STDIN>;



# ###############################################################
# ===============================================================
print "\n4. Creating the p-diagram: 4_p_diagram \n";
print "======================================================\n";
print "This part takes all the collected information and calculates the p-diagram.\n";
print ">>> Press enter to continue\n";
$input = <STDIN>;


$pdiagram = 'perl 4_p_diagram/pdiagram_pipe.pl';
system($pdiagram);



# This part then extracts the prosodic phrase information from the p-diagram and puts it into
# an array @prosword. This array is passed as an argument to the syntactic disambiguation process.
open(FILE9, "4_p_diagram/p_diagram.txt");

while (defined(my $t = <FILE9>)) {
	chomp($t);
	foreach $line ($t){
		if ($line =~ "pros_phrase"){
			@prosword = split(/\t/, $line);
			shift(@prosword);
		}
	}
}
 close(FILE9);

# ===============================================================
print "\n5. Disambiguating syntax\n";
print "======================================================\n";
print ">> Starts perl program ps_interface.pl, hands over prosodic_phrasing array\n";
print ">> gets s-string, writes an xlerc file to parse string and save fchart \n";
print ">> OUTPUT: 5_syn_parse/fchart.pl\n";
print "======================================================\n";
print "--> Press enter to continue\n";

 $input = <STDIN>;

system('perl', '5_syn_parse/ps_interface.pl', @prosword) == 0 or die "failed";


