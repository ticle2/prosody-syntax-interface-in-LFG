#!/usr/bin/perl
# TB, 7.6.2022
# This script resorts the results from the Praat extraction.
# It mirrows section 1.2. in the overall pipeline (with adjustments in paths etc)


# ###############################################################

# This script resorts output from Praat scripting for further analysis.
# Resorting table_norm_st.txt which contains 5 f0 measures/syllable, unique
# time markers, and semitones, into a file where the file name is split and file is cleaned
# if there is a pause, it is deleted from the final output, the syllable and subinterval-numbers
# are adjusted, the information is kept in two variables for later use
# This is necessary because otherwise the pitch estimations would be completely out of hand

open(OUTPUT, "> 1_extract_signal/table_norm_st_res.txt");

print OUTPUT "SyllNr\tSyll\tSubIntNr\tDur\tF0mean\tF0mean_sub\tSemitone";

$filename = "";

@syll_list = ();

open(FILE, "1_extract_signal/table_norm_st.txt");  

$pause = "n";

while (defined(my $t = <FILE>)) {
	chomp($t);
	foreach $line ($t){
			if ($line =~ "<p:>" ){
				@line_split = split(/\t/, $line);
				$pause = "y";
				$pause_dur = $line_split[4];
				$pause_order = $line_split[1];
				}
			if (($line !~ "File") & ($line !~ "<p:>")) {
				@line_split = split(/\t/, $line);
				# @name_split = split(/_/, $line_split[0]);
				if ($line_split[5] =~ /undefined/){
						$line_split[5] = "NA";
					}
				if ($line_split[6] =~ /undefined/){
						$line_split[6] = "NA";
					}
				if ($line_split[7] =~ /undefined/){
						$line_split[7] = "NA";
					}
				
				if ($pause eq "n"){
				print OUTPUT "\n$line_split[1]\t$line_split[2]\t$line_split[3]\t$line_split[4]\t$line_split[5]\t$line_split[6]\t$line_split[7]";
					}
				elsif ($pause eq "y"){
					$new_syll_nr = $line_split[1] -1;
					$new_sub_nr = $line_split[3] -5;
				print OUTPUT "\n$new_syll_nr\t$line_split[2]\t$new_sub_nr\t$line_split[4]\t$line_split[5]\t$line_split[6]\t$line_split[7]";
					}
				
		}
	}
}
if ($pause eq "y"){
print OUTPUT "\nPause\t$pause_dur\t$pause_order\n";
	print "pause duration is $pause_dur and position is $pause_order\n";
	}


close(FILE);
close(OUTPUT);
