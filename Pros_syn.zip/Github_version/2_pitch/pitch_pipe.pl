#!/usr/bin/perl
# TB, 7.6.2022
# This remodels and interprets the pitch movements

use Statistics::R;

# ###############################################################
# ===============================================================
print "\n2.1. Creating a hash with basic pitch information values for each subinterval\n";
print "======================================================\n";
print ">> SyllNr, SyllValue, position in syll (mid, prec or foll boundary), semitone for each intervall \n";
print "======================================================\n";
#print "--> Press enter to continue\n";
#$input = <STDIN>;


open(FILE2, "1_extract_signal/table_norm_st_res.txt");  

%store = {};
$count_pos = 0;  # this one is used to count in 5-steps to see where in the syllable the current position is
$SyllID = 0;

@syllables = ();  # This is the array where the syllables are just stored in a linear order --> for lexical matching 
@interval = ();   		# storing all the subinterval IDs
@semitone_raw = ();   	# simply storing all the semitones 
while (defined(my $t = <FILE2>)) {
	chomp($t);
	foreach $line ($t){
		if ($line !~ "SubIntNr"){
			@store_in_store = ();      # Pre-collecting the information for the hash %store
			@line_split = split(/\t/, $line);
			$syllNr = $line_split[0];
			$syll = $line_split[1];
			# Storing syllable in Array every time new ID is reached (needed for lex match)
			if ($syllNr ne $SyllID){
				push(@syllables, $syll);
				$SyllID = $syllNr;
			}
			$intvall = $line_split[2];  # This is the subinterval number
			$st = $line_split[6];
			push(@semitone_raw, $st);
			push(@interval, $intvall);
			push(@store_in_store, $syllNr); # From here one, the hash is created. Store SyllNr
			push(@store_in_store, $syll);	# Store syllable value
			# This part establishes whether the interval is at a border of the syllable
			$count_pos ++;
			if ($intvall == 1){
				push(@store_in_store, "first"); # first element
				}
			elsif ($count_pos == 5){
		    	push(@store_in_store, "prec"); # preceding border
		    }
		    elsif ($count_pos == 6){
		    	push(@store_in_store, "foll"); # following border
		    	$count_pos = 1;		# resetting (position 6 = position 1 in new syllable)
		    }
		    else{
		    	push(@store_in_store, "mid"); # mid syllable
		    } 
			push(@store_in_store, $st);   # add semitone to pre-array
			$store{$intvall}=[@store_in_store];   # each subinterval number is stored as key with @store_in_store as value
		}
	}
}

# This replaces the position cue "prec" in the last subintervall with "last" (cleaning up)
splice(@store_in_store, 2, 2);
push(@store_in_store, "last");
push(@store_in_store, $st); 
$store{$intvall}=[@store_in_store];



close(FILE2);

# ++++++  Elements in hash %store: 
# key: subintervallNumber
# Values (as array): 0:SyllNr, 1: SyllValue, 2: first/last (in overall signal) or prec/foll/mid 
# (at syllable border) , 3: Semitone

#### Use this if the output needs to be checked
# foreach my $key (sort { $a <=> $b} keys %store) {
#	print "$key: $store{$key}[0] $store{$key}[1] $store{$key}[2] $store{$key}[3]\n";
# } 

# ###############################################################
# ===============================================================
print "\n2.2. Getting rid of the outliers: 1st/3rd q -/+ 1.5 IQR) \n";
print "======================================================\n";

##### ======================================================================
####### 2a) Getting rid of outliers 
## By estimating the IQR and the quantiles, the outliers are defined as data points which 
## are  smaller than 1st quantile - 1.5 IQR or larger than 3rd quantile + 1.5 IQR
## The data is sorted, all of these measures are estimated, then a new array with all
## semitones is created replacing all outliers with "NA"
@semitones = ();       #After the outliers are taken out, the cleaned semitones are stored in here
@sorting = ();
$sum_st = 0; # sum of all semitones in the array
$count_st = 0;  # counting the number of all semitones

foreach $st (@semitone_raw){
	if ($st ne "NA"){
		$sum_st += $st;
		$count_st ++;
		push(@sorting, $st);   # create an array just for sorting, median, IQR etc
	}
}

# the mean
$mean = $sum_st/$count_st;

# rounded quarters
$quart = $count_st/4;  # 1st Quartile
$quart = int($quart);
$quart_3 = 3 * $quart; # 3rd Quartile

# approximate median 
$half = $count_st/2;
$half = int($half); 

# Sorting the numbers in @ sorting from low to high
@sort_st = sort { $a <=> $b } @sorting;

# Estimating the IQR: 3rd quantile - 1st quantile
$IQR = $sort_st[$quart_3]-$sort_st[$quart];

# check the data so far
# print  "\n median: $sort_st[$half] >> mean: $mean >> 1stquart: $sort_st[$quart] >> 3rdquart: $sort_st[$quart_3] >> IQR: $IQR  \n";

# Identifying the borders for outliers 
$IQR_out = ($IQR/2) * 3; # calculating the 1.5 IQR
$out_bottom = $sort_st[$quart] - $IQR_out;  # Subtracting it from 1st Quantile (lower border for outliers)
$out_top = $sort_st[$quart_3] + $IQR_out; # Adding it to 3rd Quantile (upper border for outliers)

# Re-creating the semitone array by replacing all outliers with "NA"
foreach $st (@semitone_raw){
	if ($st ne "NA"){
		if (($st < $out_bottom) || ($st > $out_top)){
			# print "$st\n";
			push(@semitones, "NA")
		}
		else{
			push(@semitones, $st)
		}
	}
	else{
		push(@semitones, "NA")
	}
}	

#### Uncomment if you want to check the output
# $count_temp = -1;
#foreach $semi (@semitone_raw){
#	$count_temp ++;
#	print "$semitone_raw[$count_temp] --> $semitones[$count_temp]\n"
#}



# ===============================================================
print "\n2.3. Get Residuals via R --> file.ps for a visualisation \n";
print "======================================================\n";

##### ======================================================================
######  Residuals via call to R
# Preparing the variables for the analysis
# The two arrays with all semitones and subintervals are put into an R-readable form.
# This is done via a soubroutine, which creates an R-compatible string where there is a
# variable <- c(bunch of values from the array)

&Prep_stats(\@semitones, $semis, "semisR"); #var0, var1, var2
&Prep_stats(\@interval, $intv, "intvR");

sub Prep_stats {
	$_[1] = "$_[2] <- c(";		# $var1 ($semis/$intv) is defined as var2 (semisR/intvR): start c(omine)
	$count = 0;
	$length = @{$_[0]};   		# measure the length of the array in var0: @semitones/@interval
	foreach $el (@{$_[0]}){		# foreach element in the array
		$count ++;				# add one to count
		if ($count < $length){	# if count smaller length
			$_[1] .= "$el, ";	# add element within c( )
		}
		else{
			$_[1] .= "$el)";    # final: close boundary
		}
	}
}

my $R = Statistics::R->new();	# call up R

# Also, apparently it is enough to define a variable without q`` and then just run that
#$val = "values <- c(11.31, 11.42, 11.5, 11.7, 11.9, 12.58, 12.78, NA, 13.22, 13.32)";
$R->run($semis);	# read the variables into R
$R->run($intv);

$R->run(			# get the residuals from the lm semisR~intvR
	q`resids <- resid(lm(semisR~intvR, na.action=na.exclude))`,
	q`residuals <- c()`, 	# create a new array and read the resids into that array
	q`for (i in resids){ 	
		residuals <- c(residuals, i)
	}`
);

my $resids = $R->get( 'residuals' ); # get this array back from R to perl

$count_resid = 0;			# The residuals are then added to the hash %store for each subinterval
foreach $el (@$resids){		# $count_resid ensures it ends up with the right interval  (from 1 to ...)
	$count_resid ++;
	## Use this chance to replace the old semitones with the cleaned ones!
	pop  @{$store{$count_resid}};
	push @{$store{$count_resid}}, $semitones[$count_resid-1];
	# Now add the residuals
	push @{$store{$count_resid}}, $el;
}


#### for a picture
# $output_file = "2_pitch/file.ps";
$output_file = "2_pitch/file.ps";
$R->run(qq`postscript("$output_file", width=500, height=300)`);
$R->run(q`plot(intvR, semisR)`);
$R->run(q`abline(lm(semisR~intvR))`);
$R->run(q`dev.off()`); 

$R->stop();

#### Use this if the output needs to be checked
#foreach my $key (sort { $a <=> $b} keys %store) {
#	print "$key: $store{$key}[0] $store{$key}[1] >> $store{$key}[3] >> $store{$key}[4]\n";
#	print "$key: $store{$key}[0] $store{$key}[1] $store{$key}[2] $store{$key}[3] $store{$key}[4]\n";
# } 

# ++++++  Elements in hash %store: key/intervall 
# ++++++  Values: 0:SyllNr, 1: SyllValue, 2: first/last or prec/foll/mid, 3: Semitone_clean, 4: Residual



# ###############################################################
# ===============================================================
print "\n2.4. Determining Min and Max\n";
print "======================================================\n";
print ">> Output: 2_pitch/content_hash_raw.txt (only as overview of mins/max)\n";
print "======================================================\n";
# print "--> Press enter to continue\n";
##### ======================================================================
# The following section goes through the semitones one by one, checking whether the current 
# st is higher/lower than the previous one(s). Once a min/max is found a count_max/min is started.
# This count is re-started every time a min/max is found. If the count reaches 5 (= 1 Syllable) 
# then this st is assumed to be a "real" min/max

$count_st = 0; # this is basically the subinterval count
$max = 0;	# this looking for H tones  -- set low so it triggers immediately
$min = 25; 	# this looking for L tones  -- set high so it triggers immediately
$set_max = "n";   # this is the marker set if a max is found
$set_min = "n";	  # this is the marker set if a min is found
$status = "";

@slope_id = ();  # storing the IDs of the min/max
@slope_st = ();  # storing the semitone values of the min/max


foreach $st (@semitones) {
	$count_st ++;
		# if not NA and if it is NOT the first syllable
	if (($st ne "NA") && ($store{$count_st}[0] !~ 1)){
		# if semitone is smaller than min, register this one as $min_st, 
		# reset $min to $st value to see whether lower ones are following
		if (($st < $min) && ($status ne "min")){ # prevents two mins
			$count_min = 0; # this is to measure how LONG the minimum stays a minimum
			$min = $st;					# set new value
			$min_st = $st;				# ??
			$min_st_ID = $count_st;   	# keeping track of the interval number
			$set_min = "y";				# signaling that a min has been set
		}
		if (($st > $max) && ($status ne "max")) { # prevents two maxs without a min
			$count_max = 0; # this is to measure how LONG the max stays a max
			$max = $st;					# set new value
			$max_st = $st;				# ??
			$max_st_ID = $count_st;		# keeping track of the interval number 
			$set_max = "y";				# signaling that a max has been set
		}
	}
	if ($set_min eq "y"){ # count_max is only running if a max has been set
		$count_min ++;	# this is reset every time a minimum is reached
	} 
	if ($set_max eq "y"){ # count_max is only running if a max has been set
		$count_max ++;	# this is reset every time a maximum is reached
	}
	# print "$count_max : $count_min > $st\n";
	
	# This only applies at the last value of the array: It adds +5 to the min/max_count so 
	# min/max at the very end of the clause can be captured as well. Same for max.
	# The status prevents two max following each other
	if (($count_st == $length) && ($status ne "max")){ 
		$count_max = $count_max + 5;
	}
	if (($count_st == $length) && ($status ne "min")){ 
		$count_min = $count_min + 5;
	}
	# Once count_min/max reaches 5 (i.e., five intervals after a minimum was set = 1 syllable)
	# the $min/$max_st is declared a possible minimum, $count_min/max and $min/$max are reset 
	# The IDs and the semitones variables are furthermore stored in two parallel arrays for the
	# slope calculation
	if ($count_min >= 4){
		#print "\n## Minimum: $min_st_ID :: $min_st  ##\n "; #$semitones[$min_st_ID-1]
		push(@slope_id, $min_st_ID);
		push(@slope_st, $min_st);
		push @{$store{ $min_st_ID}}, "Min";
		$count_min = 0;
		$min = 25;
		$set_min = "n";
		$status = "min";
	}
	if ($count_max >= 4){
		#print "\n** Maximum: $max_st_ID :: $max_st  **\n "; 
		push(@slope_id, $max_st_ID);
		push(@slope_st, $max_st);
		push @{$store{ $max_st_ID}}, "Max";
		$count_max = 0;
		$max = 0;
		$set_max = "n";   # this prevents count_max from running
		$status = "max";  # this says that max has just been set
		$max_st_ID  = 0;
	}
}



# This part fills up the rest of the hash (that is not max or min) with NA
@intvall= keys %store;
for $intv (@intvall) {
	if (($store{$intv}[5] ne "Max") && ($store{$intv}[5] ne "Min")) {
		push @{$store{$intv}}, "NA";
	}
}

$found_value = "n"; # This is a marker to determine the first semitone-value of the signal, so it can 
	# be used in the caluculation of the slope
foreach my $key (sort { $a <=> $b} keys %store) {
	if ($found_value eq "n"){
		if ($store{$key}[3] =~ /\d/){  # If you find the first number, then stop
			$found_value = "y"; 	# by marking the $found_value as yes
			# then put these values into the slope-arrays
			unshift(@slope_id, $key); #Putting the very first signal value on the array
			unshift(@slope_st, $store{$key}[3]);    #Putting the very first signal value on the array				
		};		
	} #uncomment this for an overview of the hash
	#print "$key: $store{$key}[0] >> $store{$key}[1] >> $store{$key}[2] >> $store{$key}[3] >> $store{$key}[4] >> $store{$key}[5] \n";
}


# ++++++  Elements in hash %store: key/intervall
# ++++++  Values in array:  0: SyllNr, 1: SyllValue, 2: first/last and (border) prec/foll/mid, 3: Semitone, 4: Residual  5: Max/Min/NA

# ===============================================================
print "\n2.5. Determining the slopes - semitone difference\n";
print "======================================================\n";
print "OUTPUT 1: relevant values: 2_pitch/content_hash_raw.txt\n";
print "OUTPUT 2: all values: 2_pitch/content_hash_raw_all.txt\n";
##### ======================================================================
###### Rising and falling slopes
# This section goes through the two slope arrays with the min and max and IDs from the previous 
# section and determines the slopes between these values ($m).
# The slope-value leading up to the min/max is stored in position 6, the slope value leaving min/max
# is stored in position 7. All other values are filled up with NA.

$length_slope = @slope_id;


$count_slope = -1;
foreach $val (@slope_id){  # this contains the subinterval-IDs which have Min or max
	$count_slope ++;
	if (($count_slope+1) < $length_slope){ #If not yet at the end of the array
		$x1 = $slope_id[$count_slope];	# the current value
		$x2 = $slope_id[$count_slope+1]; # the next value
		$y1 = $slope_st[$count_slope];
		$y2 = $slope_st[$count_slope+1];
		$m = sprintf("%.2f", ($y2 - $y1) / ($x2 -$x1)); #this is the ratio between the values and the distance between a min and a max. A positive value is a rise, a negative is a fall
		push @{$store{$x2}}, $m;   # This is the slope-to --> stored with next item
		if (!(exists $store{$x1}[6])){  # If
			push @{$store{$x1}}, "NA";   #first value (not min/max) does not get a slope leading TO it
		}
		push @{$store{$x1}}, $m; #this is position 7, the slope leading FROM the value
	}
}

# Fill up hash with NA if there is no slope value
@intvall= keys %store;
for $intv (@intvall) {
	if (!(exists $store{$intv}[6])) {
		push @{$store{$intv}}, "NA";
	} 
	if (!(exists $store{$intv}[7])) {
		push @{$store{$intv}}, "NA";
	} 
}

# ++++++  Elements in hash %store: key/intervall Values in array:  
# ++++++  Values in array:  0: SyllNr, 1: SyllValue, 2: (border) prec/foll/mid, 3: Semitone, 4: Residual  5: Max/Min/NA, 6: slope/NA TO, 7: slope/NA FROM
##### ======================================================================
# Overview
# (prints out the intervals with mins and maxs)
open(OUTPUT2, "> 2_pitch/content_hash_raw.txt");
print OUTPUT2 "This contains ONLY the keys+values that have mins/maxs; others are not printed\n";
foreach my $key (sort { $a <=> $b} keys %store) {
	if ($store{$key}[5] ne "NA"){
		print OUTPUT2 "$key\t$store{$key}[0]\t$store{$key}[1]\t$store{$key}[2]\t$store{$key}[3]\t resid: $store{$key}[4]\t Min/Max: $store{$key}[5]\t Slope-to: $store{$key}[6]\t Slope-from: $store{$key}[7] \n";	
	}
}
close(OUTPUT2);

open(OUTPUT2B, "> 2_pitch/content_hash_raw_all.txt");
foreach my $key (sort { $a <=> $b} keys %store) {
	print OUTPUT2B "$key\t$store{$key}[0]\t$store{$key}[1]\t$store{$key}[2]\t$store{$key}[3]\t  $store{$key}[4]\t$store{$key}[5]\t$store{$key}[6]\t$store{$key}[7] \n";	
}
close(OUTPUT2B);



