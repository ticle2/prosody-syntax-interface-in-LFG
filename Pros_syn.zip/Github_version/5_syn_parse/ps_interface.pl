#!/usr/bin/perl
# TB, Jan 2022
# This script is establishing the interface between p-structure and c-structure

# This is the array with the prosodic phrasing of the p-diagram. It was handed over by the main script pipeline.pl

@prosword = @ARGV;

print "\n5.1. Parsing the s-string \n";
print "======================================================\n";

# ===================================================================================
# 1. Parse the s-string and get an analysis, print out fchart in prolog

open(FILE6, "3_match_lex/s_string.txt");  

# "\n================================================================================\n";
# Need to extend the string as long as files are not fully annotated

while (defined(my $t = <FILE6>)) {
	chomp($t);
	foreach $line ($t){	
		if ($line ne ""){
			if ($line =~ /^dass/){
				$sstring = "Sie sahen, $line.";
			}
			elsif ($line =~ /^als/){
				$sstring = "Sie jubelten, $line.";
			}
			elsif ($line =~ /^musste/){
				$sstring = "Da $line.";
			}
			
		}
	}
}
close(FILE6);

#$cmd = 'rm ../gram_xle/xlerc';
#system($cmd);

#### Writing the initial xlerc file
open(OUTPUT7, ">5_syn_parse/xlerc");  


print OUTPUT7 "set showNumbers 0 ;\n";	# turns off node numbers in c-structure window
print OUTPUT7 "set showFSNumbers 0 ;\n";   # turns off node numbers in f-structure window
print OUTPUT7 "set xletreefont {Courier 20}\n";
print OUTPUT7 "set xletextfont {Courier 20}\n";
print OUTPUT7 "set xleuifont {Courier 20}\n";
print OUTPUT7 "set xlefsfont {Courier 20}\n";
#set showPredsOnlyFStruct 1
print OUTPUT7 "set showPredsOnlyFSChart 1\n";
print OUTPUT7 "set backgroundColor white\n";

print OUTPUT7 "create-parser 5_syn_parse/gendat.lfg\n";
print OUTPUT7 "parse {$sstring}\n";
print OUTPUT7 "print-prolog-chart-graph 5_syn_parse/fchart.pl\n";
# print OUTPUT7 "exit\n";

close(OUTPUT7);

$XLE = 'xle -f 5_syn_parse/xlerc';

system($XLE) == 0 or die "die";

print "\n5.2. Identification of ambiguity position \n";
print "======================================================\n";
#print ">> Finds ambiguation in constraints section of fchart.pl, saves options (var - arguments of verb)\n";
#print ">> in section C-structure, finds the fspan associated with each var \n";
#print ">> Identifies the surface form(s) associated with that fspan, marks position\n";
#print "======================================================\n";
#print "--> Press enter to continue\n";

# ===================================================================================
# 2. Analyse the fchart output


open(FILE6, "5_syn_parse/fchart.pl");  

$section = ""; #to keep track of which section we are in
@ambig = ();
$count = 0;
%options = {};
$max_1 = 0; # only subject
$min_1 = 100;
$max_2S = 0; #subject
$min_2S = 100;
$max_2O = 0; #object
$min_2O = 100;
@s_string = ();


while (defined(my $t = <FILE6>)) {
	chomp($t);
	foreach $line ($t){	
		if ($line =~ m/choice\(/){
			@lines = split(/\[|\]/, $line);
			@options = split(/,/, $lines[1]);
			$nr_options = @options;
		}
		# If $nr_options == 1 --> just run the original script (without exit): no ambiguity
		# THIS OPTION STILL NEEDS TO BE INCLUDED
		# else, if there are two options, do the following
		# First make sure you are always in the right section
		if ($line =~ m/% Constraints/){
			$section = "constraints";
		}
		if ($line =~ m/% C\-Structure/){
			$section = "c-structure";
			#print $section;
		} 
		# check where the ambiguity is
		if ($section eq "constraints"){
			# This is the line where the verb and its arguments are stored. If there is an 
			# A1/A2 (A\d) to be found, then this is one of two options and the ambiguity can
			# be found in the argument structure of the verb
			if (($line =~ m/cf\(A\d+,eq\(var/) && ($line =~ m/semform/)){
				$count ++;  # basically counts the options (how often this line appears)
				# This works, finds all options, print ">>> $line\n";
				@arg = split(/\[|\]/, $line);
				@args = split(/,/, $arg[1]);
				$nr_args = @args;  # noting down how many arguments the verb has (1:gen, 2:dat)
				if ($count == 1){ # If this is the first line/ the first option
					# push (@s_string, "A1");   # this should also exist for other options
					# creating hash with key= option A1, and value [nr of args, arg1, (arg2)]
					if ($nr_args == 2){
						push(@{$options{"A1"}}, $nr_args);
						push(@{$options{"A1"}}, $args[0]);
						push(@{$options{"A1"}}, $args[1]);
					}
					elsif ($nr_args == 1){
						push(@{$options{"A1"}}, $nr_args);
						push(@{$options{"A1"}}, $args[0]);
					}
				}
				if ($count == 2){ # If this is the second line/ the second option
					# creating hash with key= option A2, and value [nr of args, arg1, (arg2)]
					if ($nr_args == 2){
						push(@{$options{"A2"}}, $nr_args);
						push(@{$options{"A2"}}, $args[0]);
						push(@{$options{"A2"}}, $args[1]);
					}
					elsif ($nr_args == 1){
						push(@{$options{"A2"}}, $nr_args);
						push(@{$options{"A2"}}, $args[0]);
					}
				}
			}
		} #constraint section is done, hash with options and relevant arguments created
		  # moving on to c-structure
		elsif ($section eq "c-structure"){
			foreach my $key (keys %options) {
				# check these out for each option
				# fspan + argument gives you the min and max value (internal index) of that argument
				# there is usually more than one relevant fspan (for each word, for whole XP) so 
				# need to find the smallest and the largest min and max
				if (($options{$key}[0] == 1) && ($line =~ /\Q$key/) && ($line =~ /\Qfspan($options{$key}[1]/)){
					# This one only has a subject and this section determines the 
					# span of the subject
					@line_split = split(/,/,$line);
					$from_1 = $line_split[-2];
					$to_1 = $line_split[-1];
					$to_1 =~ s/\)\)//;
					if ($to_1 > $max_1){
						$max_1 = $to_1;
					} 
					if ($from_1 < $min_1){
						$min_1 = $from_1;
					} 
					#print "$min_1 >> $max_1: $line\n";
				}
				elsif (($options{$key}[0] == 2) && ($line =~ /\Q$key/)){
					# This one has a subject and an object and this section determines the 
					# $opt = $key; # XXX what is this?
					# span of the subject
					if ($line =~ /\Qfspan($options{$key}[1]/){
						@line_split = split(/,/,$line);
						$from_2S = $line_split[-2];
						$to_2S = $line_split[-1];
						$to_2S =~ s/\)\)//;
						if ($to_2S > $max_2S){
							$max_2S = $to_2S;
						} 
						if ($from_2S < $min_2S){
							$min_2S = $from_2S;
						} 
					#	print "$min_2S >> $max_2S: $line\n";
					}
					# The corresponding Object
					elsif ($line =~ /\Qfspan($options{$key}[2]/){
						@line_split = split(/,/,$line);
						$from_2O = $line_split[-2];
						$to_2O = $line_split[-1];
						$to_2O =~ s/\)\)//;
						if ($to_2O > $max_2O){
							$max_2O = $to_2O;
						} 
						if ($from_2O < $min_2O){
							$min_2O = $from_2O;
						} 
						#print "$min_2O >> $max_2O: $line\n";
					}
				}
			}
			# Moving on to the surface forms (actually part of c-structure section)
			# XXX starting at comma!!!! (cheat, should be able to do whole clause)
			if ($line =~ /surfaceform\(\d,','/){ 
				$section = "surface";	
			}
		}
		elsif ($section eq "surface"){
			@split_line = split(/\(/, $line);
			@split_line2 = split(/,/, $split_line[2]);
			# put all s_forms in an array @s_string
			$sform = $split_line2[1];
			$sform =~ s/'//g;
			push (@s_string, $sform);
			# looking for the max span of the subject in S-O --> that boundary is crucial
			# for this particular constructions.
			# Put everything into the a_string, XXX being the marker
			if ($split_line2[3] == $max_2S){
				push (@s_string, "XXX");	
			}
		}
	}
}

close(FILE6);


#foreach $el (@s_string){
#	print "$el\n";
#}

print "\n5.3. Checking back with p-structure \n";
print "======================================================\n";
#print ">> a) Match the s-string index (words) back to p-string index (syllables) \n";
#print ">> b) check in the attribute array prosodic-phrasing for that position \n";
#print ">> If there is a PhP, then take option with two arguments dat; else take option with one argument (gen)\n";
#print ">> c) Rewrite fchart(_new).pl so the identified option is selected. Parse fchart.\n";
#print "======================================================\n";

#print ">>> Press enter to continue\n";
#$input = <STDIN>;

# "\n================================================================================\n";
# a) In this section, the s-string is matched against the results_phon.txt (created earlier), # where each s-form is paired with the p-form information

open(FILE7, "3_match_lex/results_phon.txt");  
$count = 0;
$match = "search";
$syllnr = 0;

# $count is only increasing if the $line matches the current position in the s-string
while (defined(my $t = <FILE7>)) {
	chomp($t);
	foreach $line ($t){	
		# if an sform item was found (see below), then the p-form is split and the nr of syllables 
		# of that pform is added to the syllable count (syllnr) 
		if ($match eq "found"){
			@pform_split = split(/\+/, $line);
			#print $pform_split[2];  # this is the number of syllables encoded in every p-form
			$syllnr += $pform_split[2];
			$match = "search"; # look for next s-form
		}
		# this is the marker of the boundary, saves syllnr 
		# --> check in prosodic phrasing array whether there is a boundary there
		if ($s_string[$count] eq "XXX"){  
			$count++;
			$bd_index = $syllnr; 
			#print "$bd_index >> $s_string[$count]\n";
			$bd_word = $s_string[$count-2];
		}
		# this is the main loop checking for the next sform item
		if ($line eq $s_string[$count]){
			$match = "found";
			#print "$line > $s_string[$count] : $count \n";
			$count++
		}
	}
}

close(FILE7);

# =====================
# b) Checking whether there is a prosodic boundary at the position in question:
$checkpoint = $prosword[$bd_index-1];

print ">> this is the checkpoint: $checkpoint\n";
# preparing the extraction of which option belongs to which argument structure
foreach my $key (keys %options) {
	if ($options{$key}[0] == 1){
		$nobound = $key;
	}
	elsif ($options{$key}[0] == 2){
		$bound = $key;
	}
}
if ($checkpoint =~ /\)pp/){
	print "There is a boundary after '$bd_word'. Use option $bound.\n";
	$new_line = "\tselect($bound, 1)\n";
}
else{
	print "There is no boundary after '$bd_word'. Use option $nobound\n";
	$new_line = "\tselect($nobound, 1)\n";
	}

# =====================
# c) Rewriting fchart and parsing it again

open(FILE8, "5_syn_parse/fchart.pl"); 
open(OUTPUT8, ">5_syn_parse/fchart_new.pl"); 

while (defined(my $t = <FILE8>)){
	chomp($t);
	foreach $line ($t){	
		if ($line =~ m/select\(A/){
			$line = $new_line;
		}
		print OUTPUT8 "$line\n";
	}
}	
			
close(FILE8);		
close(OUTPUT8);			
		
open(OUTPUT9, ">5_syn_parse/xlerc");  

print OUTPUT9 "set showNumbers 0 ;\n";	# turns off node numbers in c-structure window
print OUTPUT9 "set showFSNumbers 0 ;\n";   # turns off node numbers in f-structure window
print OUTPUT9 "set xletreefont {Courier 20}\n";
print OUTPUT9 "set xletextfont {Courier 20}\n";
print OUTPUT9 "set xleuifont {Courier 20}\n";
print OUTPUT9 "set xlefsfont {Courier 20}\n";
#set showPredsOnlyFStruct 1
print OUTPUT9 "set showPredsOnlyFSChart 1\n";
print OUTPUT9 "set backgroundColor white\n";

print OUTPUT9 "create-parser 5_syn_parse/gendat.lfg\n";
print OUTPUT9 "parse {$sstring}\n";
print OUTPUT9 "read-prolog-chart-graph 5_syn_parse/fchart_new.pl\n";
#print OUTPUT9 "exit\n";

close(OUTPUT9);

$XLE = 'xle -f 5_syn_parse/xlerc';

system($XLE) == 0 or die "die";
	