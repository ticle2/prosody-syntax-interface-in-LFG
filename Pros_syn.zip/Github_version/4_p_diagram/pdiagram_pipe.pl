#!/usr/bin/perl
# TB, 2022

# ###############################################################
# ===============================================================
print "\n 4.1. Initialising hash %pdiagram with values from speech signal\n";
print "======================================================\n";

# This snippet goes back to the extracted speech signal data. It collects the syllable nr,
# the value, the duration, and F0mean and stores these in a hash, where the SyllNr is the key
# Later --> this is the Vectorindex

%pdiagram = {};
$SyllID = 0;
$pause = "n";

open(FILE2, "1_extract_signal/table_norm_st_res.txt");


while (defined(my $t = <FILE2>)) {
	chomp($t);
	foreach $line ($t){
		if (($line !~ "SubIntNr") & ($line !~ "Pause")){
			@pdiagram_values = ();
			@line_split = split(/\t/, $line);
			$syllNr = $line_split[0];
			$syll = $line_split[1];  # string
			$dur = $line_split[3];
			# These don't really need to go in there - if yes, then recalculate st for whole syllable
			# $st = $line_split[7];   
			$F0mean = $line_split[4];
			push(@pdiagram_values, $syll);
			push(@pdiagram_values, $dur);
			push(@pdiagram_values, $F0mean);
			if ($syllNr ne $SyllID){
				$SyllID = $syllNr;
				$pdiagram{$SyllID}=[@pdiagram_values];
			}
		}
		elsif ($line =~ "Pause"){
			@line_split = split(/\t/, $line);
			$pause_dur = $line_split[1];
			$pause_pos = $line_split[2];
			print "Pause duration is $pause_dur and pause position is $pause_pos\n";
			$pause = "y";
		}
	}
}

close(FILE2);


#foreach $key (sort { $a <=> $b} keys %pdiagram) {
#	print "$key\t$pdiagram{$key}[0]\t$pdiagram{$key}[1]\t$pdiagram{$key}[2]\n";	
#}


# ###############################################################
# ===============================================================
print "\n 4.2. Putting in the lexical p-form information\n";
print "======================================================\n";

# This part extracts the p-form information from results_phon.txt and adds the prosodic 
# word information and the stress pattern to each syllable in the pdiagram hash

open(FILE5, "3_match_lex/results_phon.txt");  

$count_syll = 0;

while (defined(my $t = <FILE5>)) {
	chomp($t);
	foreach $line ($t){
		if ($line =~ /\+/){
			$count_syll ++;
			@line_split = split(/\+/, $line);
			$NrSylls = $line_split[2];
			# If there is only one syllable, then put stress and prosodic pattern in hash
			if ($NrSylls == 1){
				push (@{$pdiagram{$count_syll}}, $line_split[3]); # add stress
				if ($line_split[1] eq "pw"){
					push (@{$pdiagram{$count_syll}}, "(σ)");
				}
				elsif ($line_split[1] eq "us"){
					push (@{$pdiagram{$count_syll}}, "σ");
				}
				elsif ($line_split[1] eq "=cl"){
					push (@{$pdiagram{$count_syll}}, "=cl");
				}
			}
			# If there is more than one syllable, then split the stress pattern and distribute 
			# over the next few syllables.
			# Also split up prosodic words into left and right brackets
			 elsif ($NrSylls > 1){
			 	@stress_patt = split(//, $line_split[3]);
			 	$length_stress = @stress_patt;
			 	$count_stress = 1;
			 	foreach $stress (@stress_patt){
			 		if ($count_stress <= $length_stress){
			 			$stresspos = $count_syll - 1 + $count_stress;
			 			push (@{$pdiagram{$stresspos}}, $stress);
			 			$count_stress ++;
			 		}
			 	}
			 	push (@{$pdiagram{$count_syll}}, "(σ ");
			 	$count_syll = $count_syll - 1 + $NrSylls;
			 	push (@{$pdiagram{$count_syll}}, " σ)");	
			}
		}
	}
}

# Use this if you have to fill up syllables! Important with 3-syllabic things
@keys= keys %pdiagram;
foreach $syll (@keys) {
	#print "\n $syll: $pdiagram{$syll}[4]";
	if ($pdiagram{$syll}[4] !~ /σ/){
		print "xx\n";
		push @{$pdiagram{$syll}}, "σ";
	}
}
			
			
close(FILE5);


#foreach $key (sort { $a <=> $b} keys %pdiagram) {
#	print "$key\t$pdiagram{$key}[0]\t$pdiagram{$key}[1]\t$pdiagram{$key}[2] \t$pdiagram{$key}[3]\t$pdiagram{$key}[4]\n";	
#}

# ###############################################################
# ===============================================================
print "\n 4.3. Categorizing the different raw values (%store)\n";
print "======================================================\n";

# ++++++  Elements in hash %pdiagram: key: syllable number (all)
# 	      Values in array: 0: value, 1: duration 2: F0mean 3: stress, 4: prosody 


# This part recreates the %store hash

open(FILE6, "2_pitch/content_hash_raw_all.txt");

%store = {};


while (defined(my $t = <FILE6>)) {
	chomp($t);
	foreach $line ($t){
		if ($line !~ "HASH"){	
			@store_array = ();	
			@line_split = split(/\t/, $line);
			push(@store_array, $line_split[1]); #SyllNr
			push(@store_array, $line_split[2]); #value
			push(@store_array, $line_split[3]); #border
			push(@store_array, $line_split[4]); # st
			push(@store_array, $line_split[5]); #resid
			push(@store_array, $line_split[6]); #max/min
			push(@store_array, $line_split[7]); # slope to
			push(@store_array, $line_split[8]); # slope from
			$store{$line_split[0]}=[@store_array];
		}
	}
}

#foreach $key (sort { $a <=> $b} keys %store) {
#	if ($store{$key}[5] ne "NA"){
#		print "$key\t$store{$key}[0]\t$store{$key}[1]\t$store{$key}[2]\t$store{$key}[3]\t  $store{$key}[4]\t $store{$key}[5]\t $store{$key}[6]\t $store{$key}[7] \n";	
#	}
#}
close(FILE6);

# ++++++  Elements in hash %store: key/intervall Values in array:  
#  		  Values in array:  0: SyllNr, 1: SyllValue, 2: (border) prec/foll/mid, 
#		  3: Semitone, 4: Residual  5: Max/Min/NA, 6: slope/NA TO, 7: slope/NA FROM

##### ======================================================================
##### ======================================================================
# b) reorganises hash %store into %restore by categorising the raw values

# reorganising and categorising the values from the hash %store
open (OUTPUT6, "> 4_p_diagram/info_raw_categorized.txt"); 

%restore = {};
foreach my $key (sort { $a <=> $b} keys %store) {
	#print $key;
	if ($store{$key}[5] ne "NA"){
	    print OUTPUT6  "$key\t$store{$key}[0]\t$store{$key}[1]\t$store{$key}[2]\t$store{$key}[3]\t residual: $store{$key}[4]\t Min/Max:$store{$key}[5]\t Slope-to:$store{$key}[6]\t Slope-from:$store{$key}[7] \n";	
	    $IntvalKey = $key;
		$syllNr = $store{$key}[0];
		# initialize hash and store key IntvalKey 
		push(@{$restore{$IntvalKey}}, $syllNr);
		$pitch = $store{$key}[5];
		push(@{$restore{$IntvalKey}}, $pitch);
		#print $restore{$IntvalKey}[1];
		# add where in the syllable (mid, foll, prec)
		push(@{$restore{$IntvalKey}}, $store{$key}[2]);
		#######################################################
	 	# Categorising the value of the residual: $residvalue
		$residual = $store{$key}[4];
	 	if (($residual > 3) || ($residual < -3)) {
	 		$residvalue = "extreme";
	 		#print "\n++ $residvalue\n";
	 	}
	 	elsif ((($residual > 2) && ($residual < 3)) || (($residual < -2) && ($residual > -3))){
	 		$residvalue = "large";
	 		#print "\n++ $residvalue\n";
	 	}
	 	elsif ((($residual > 1) && ($residual < 2)) || (($residual < -1) && ($residual > -2))){
	 		$residvalue = "normal";
	 		#print "\n++ $residvalue\n";
	 	}
	 	else{
	 		$residvalue = "small";
	 		#print "\n++ $residvalue\n";
	 	}	
	 	push(@{$restore{$IntvalKey}}, $residvalue);
	 	#######################################################
	 	# checking the slopes
	 	$slope_to = $store{$key}[6];
	 	$slope_from = $store{$key}[7];
	 	# if this is not a starting tone
	 	if ($slope_to ne "NA"){
	 		#print "\n++ $slope_to\n";
	 		if (($slope_to > 0.5) || ($slope_to < -0.5)) {
	 			$lead = "strong";
	 		}
	 		else {
	 			$lead = "normal";
	 		}
	 		if (($slope_from > 0.5) || ($slope_from < -0.5)) {
	 			$trail = "strong";
	 		}
	 		elsif ($slope_from !~ /NA/){
	 			$trail = "normal";
	 		}
	 		elsif ($slope_from =~ /NA/){
	 			$trail = "end"; # this one does not seem to fire ...
	 		}
	 		#print "\n++ $lead and $trail\n";
	 	}
	 	# if this is a starting tone (these no longer used?)
	 	if ($slope_to eq "NA"){
	 		$lead = "start";
	 		if (($slope_from > 0.5) || ($slope_from < -0.5)) {
	 			$trail = "strong";
	 		}
	 		else {
	 			$trail = "normal";
	 		}
	 	}	
	 	push(@{$restore{$IntvalKey}}, $lead);
	 	push(@{$restore{$IntvalKey}}, $trail);
	 	###########################################
	 	# Now all the variables are set so now the evaluation can start
	 	# $lead, $trail, $pitch
	 	
	 	# if all three variables indicate a max with rise and fall
	 	if (($pitch eq "Max") && ($lead eq "strong") && ($trail eq "strong")){
	 		$tone = "H4";
	 		#print ">> $tone \n";
	 	}
	 	elsif (($pitch eq "Max") && ($lead eq "strong") && ($trail eq "normal")){
	 		$tone = "H3";
	 		#print ">> $tone \n";
	 	}
	 	elsif (($pitch eq "Max") && ($lead eq "normal") && ($trail eq "strong")){
	 		$tone = "H2";
	 		#print ">> $tone \n";
	 	}
	 	elsif (($pitch eq "Max") && ($lead eq "normal") && ($trail eq "normal")){
	 		$tone = "H1";
	 		#print ">> $tone \n";
	 	}
	 	# boundary tone
	 	elsif (($pitch eq "Max") && (($lead eq "normal") || ($lead eq "strong")) && ($trail eq "end")){
	 		$tone = "H-";
	 		#print ">> $tone \n";
	 	}
	 	# if all three variables indicate a min with rise and fall
	 	if (($pitch eq "Min") && ($lead eq "strong") && ($trail eq "strong")){
	 		$tone = "L4";
	 		#print ">> $tone \n";
	 	}
	 	elsif (($pitch eq "Min") && ($lead eq "strong") && ($trail eq "normal")){
	 		$tone = "L3";
	 		#print ">> $tone \n";
	 	}
	 	elsif (($pitch eq "Min") && ($lead eq "normal") && ($trail eq "strong")){
	 		$tone = "L2";
	 		#print ">> $tone \n";
	 	}
	 	elsif (($pitch eq "Min") && ($lead eq "normal") && ($trail eq "normal")){
	 		$tone = "L1";
	 		#print ">> $tone \n";
	 	}
		elsif (($pitch eq "Min") && (($lead eq "normal") || ($lead eq "strong")) && ($trail eq "end")){
	 		$tone = "L-";
	 		#print ">> $tone \n";
	 	}
	 	# This one for the very first min or max
	 	if (($pitch eq "Min") && ($lead eq "start")){
			$tone = "Ls";
		}
		if (($pitch eq "Max") && ($lead eq "start")){
			$tone = "h_s";
		} 	
		push(@{$restore{$IntvalKey}}, $tone);
		###########################################
	 	# indicate whether $residvalue is surprising, can also be more fine-grained
	 	#if (($residvalue eq "extreme") || ($residvalue eq "large")){
	 	if ($residvalue eq "extreme") {
	 		$surprise = "surprise"	
	 	}
	 	else{
	 		$surprise = "no_surprise";
	 	}
	 	push(@{$restore{$IntvalKey}}, $surprise);
	}
}


foreach my $IntvalKey (sort { $a <=> $b} keys %restore) {
	print OUTPUT6 "$IntvalKey\t $restore{$IntvalKey}[0]\t pitch: $restore{$IntvalKey}[1]\t position: $restore{$IntvalKey}[2]\t residvalue: $restore{$IntvalKey}[3]\t to: $restore{$IntvalKey}[4]\t from: $restore{$IntvalKey}[5]\t tone: $restore{$IntvalKey}[6]\t resid: $restore{$IntvalKey}[7] \n";	
}

close(OUTPUT6);

# This part for the odd case, where the low tone is actually on the previous unstressed syllable together with another (genitive in prototype: der has a max and a min). Now using position to replace
# combine all others with their info, too.

$snr = 0;   # syllable number
$check = "no";
foreach my $IntvalKey (sort { $a <=> $b} keys %restore) {
	# This section only applies if two tones were found on one syllable
	# In that case, the program checks whether there is a tone on the next syllable
	# by checking simply the next element in the hash
	# then it checks whether the next syllable is stressed by going into the pdiagram hash
	# Only then are the values placed in this vector
	if ($check eq "yes"){
		$snr_temp = $snr + 1;
		if ($snr_temp < $restore{$IntvalKey}[0]){ #checking whether there is a tone on the next 
			if ($pdiagram{$snr_temp}[3] eq "x"){
				push(@{$pdiagram{$snr_temp}}, $restore{"temp"}[6]);
				push(@{$pdiagram{$snr_temp}}, $restore{"temp"}[7]);
				
			}
		} 	
	$check = "no";
	}
	# This simply transfers the values from the %restore hash to the %pdiagram hash
	if ($restore{$IntvalKey}[0] ne $snr){
		$snr = $restore{$IntvalKey}[0];
		push(@{$pdiagram{$snr}}, $restore{$IntvalKey}[6]); 
		push(@{$pdiagram{$snr}}, $restore{$IntvalKey}[7]); 
	} 
	else{ #If there are two tones and the position of this is immediately preceding the next syll
		if ($restore{$IntvalKey}[2] eq "prec") {
			# creating a temporary array for this second tone in one syllable
			push(@{$restore{"temp"}}, @{$restore{$IntvalKey}});
			#print $restore{"temp"}[3];
			$check = "yes";
		}
	}
}

@pdia= keys %pdiagram;
for $el (@pdia) {
	if (!(exists $pdiagram{$el}[5])) {
		push @{$pdiagram{$el}}, "NA";
	} 
	if (!(exists $pdiagram{$el}[6])) {
		push @{$pdiagram{$el}}, "NA";
	} 
}

foreach $key (sort { $a <=> $b} keys %pdiagram) {
	print "$key\t$pdiagram{$key}[0]\t$pdiagram{$key}[1]\t$pdiagram{$key}[2] \t$pdiagram{$key}[3]\t$pdiagram{$key}[4]\t$pdiagram{$key}[5]\t$pdiagram{$key}[6]\n";	
}


##########################
# ===============================================================
print "\n4.4. Printing out the p-diagram:\n";
print "======================================================\n";
#print ">> Creates arrays of every attribute \n";
#print ">> Checks where there are PhPs based on pitch/tone combinations \n";
#print ">> prints p-diagram\n";
#print ">> OUTPUT: 4_p_diagram/p_diagram.txt\n";
#print "======================================================\n";

#####################################
###### Visual representation
### (still need to include duration)


@values = ();
@duration = ();
@F0mean = ();
@lexstress = ();
@tones = ();
@prosword = ();

$count_index = 0;

foreach my $key (sort { $a <=> $b} keys %pdiagram) {
	if ($key =~ /\d/){   # cleaning up the hash	
	$value = $pdiagram{$key}[0];
	$pword = $pdiagram{$key}[4];
	$tone = $pdiagram{$key}[5];
	$tone =~ s/NA//;
	# This one extra in case there is a pause
	if (($pause eq "y") & ($pause_pos == $key)){
		push (@values, "<p:>");
		push (@duration, $pause_dur);
		push (@F0mean, "-");
		push (@lexstress, "-");
		push(@prosword, "-");	
		push(@tones, "-");
		push (@resids, "-");
	}
	push (@values, $value);
	push (@duration, $pdiagram{$key}[1]);
	push (@F0mean, $pdiagram{$key}[2]);
	push (@lexstress, $pdiagram{$key}[3]);
	push(@prosword, $pword);	
	push(@tones, $tone);
	push (@resids, $pdiagram{$key}[6]);
	#print "$key > $pdiagram{$key}[0] > $pdiagram{$key}[1] > $pdiagram{$key}[2] > $pdiagram{$key}[3] > $pdiagram{$key}[4] \n";	
}}


# For some reason there were two unwanted first elements in all of these
# Now, it's only one unwanted element

shift(@prosword);
#shift(@prosword);
shift(@tones);
#shift(@tones);
shift(@lexstress);
#shift(@lexstress);
shift(@F0mean);
#shift(@F0mean);
shift(@values);
#shift(@values);
shift(@duration);
#shift(@duration);
shift(@resids);
#shift(@resids);



# DURATION
# This section on the estimation whether a syllable is particularly long
#########################################

$tempo = 0;
$count_dur = 0;
# 1st: calculate the speaker tempo in this recording over ALL syllables
foreach $el (@duration){
	$tempo += $el ;
	$count_dur += 1;
}
	
$tempo = $tempo/$count_dur;
$tempo=sprintf("%.3f",$tempo);  #runden auf drei Stellen
$tempo = 1000*$tempo;  # get rid of floats in background; calculation doesn't work
print "Speaker Tempo: ". $tempo/1000 . "\n";

##### Pack the duration references into a hash with syll number as key, and values as list
open(FILEX, "4_p_diagram/Dur_reference.txt");

# This loop goes through the reference file "Dur_reference.txt". The file stores the descriptive
# statistics for (over the whole experiment! - Calculated separately with R) in a hash called "%durations"
# a) each syllable 
# b) the speaker tempo
# The key is either the syllable number or "SpTempo"
# The value is an array containing [min, Q1, mean, Q3, max]

%durations = {};
$count_items = 0;

while (defined(my $t = <FILEX>)) {
	chomp($t);
	foreach $line ($t){
		if ($line !~ "Item") {	
			@line_split = split(/\t/, $line);
			# Check wether there are actually tabs in Dur_reference.txt!
			#print "$line_split[1]\n";
			$key = $line_split[0]; # Save first element as the key
			shift(@line_split); # Remove the first element
			$durations{$key}=[@line_split]; # key is Syll Nr or SPtempo, value is array of descriptive stats
		}
	}
}
close FILEX;

# control print_out
# foreach $key (sort { $a <=> $b} keys %durations) {
#	print "$key\t$durations{$key}[0]\t$durations{$key}[1]\t$durations{$key}[2] \t$durations{$key}[3]\t$durations{$key}[4]\n";	
#}

#print "\n>> $durations{SpTemp}[2] << \n";
# This section determines whether a speaker is slow (> mean) or fast/normal. 
$Sp_tempo = 1000*$durations{SpTemp}[2]; # 1000* to escape floats

# if the current speaker tempo is faster (=smaller) or slower (=larger) than the average speaker tempo
if ($tempo < $Sp_tempo){
	print "Speaker is fast: " . $tempo/1000 . " is faster than the mean (" . $Sp_tempo/1000 .")\n";
	$tempo_cat = "fast";
}
else{ print "Speaker is slow: " . $tempo/1000 . " is slower than the mean (" . $Sp_tempo/1000 .")\n";
	$tempo_cat = "slow";
}


###### Now take each syllable step by step and check whether it is fast or slow
# The following algorithm is used:
# if speaker is fast and syllable is slow >= Q3, then syllable is slow
# if speaker is slow, then
#	a) subtract  mean value from speaker value 
#	b) subtract the result from the syllable value. If syllable is still slow, then ok
# collect all these values in a new array for print-out (duration_cat): "-" and "slow" as values

@duration_cat = ();

$count_sylls = 0;


foreach $syll (@duration){
	$count_sylls +=1;
	if ($count_sylls < 8){ # 7 syllables are the target sequence
	$syll_dur = 1000 * $syll; # This is the syll duration * 1000 (because of floats)
	$syll_Q3 = 1000 * $durations{$count_sylls}[3];	# This is the mean Q3 * 1000 (because of floats)
	
	if ($syll_dur >= $syll_Q3){
		# print ">> This syllable is slow: dur = $syll_dur, Q3 is $syll_Q3\n";
		if ($tempo_cat eq "slow"){ # slow speaker with slow syllable
			# print "We will have to make extra calculations, because this is a slow speaker\n";
			$diff_Sp_mean = $tempo - $Sp_tempo; # speaker tempo minus mean speaker tempo (all speakers)
			$syll_dur_norm = $syll_dur - $diff_Sp_mean ;  # take that difference and subtract it from syll duration
			# print "old value: $syll_dur; new value: $syll_dur_norm\n";
			if ($syll_dur_norm >= $syll_Q3){
				 print "Syllable $count_sylls remains slow: dur = $syll_dur_norm, Q3 is $syll_Q3\n";
				push (@duration_cat, "slow");
			}
			else {  #print "This syllable is no longer slow\n";
				push (@duration_cat, "-");
			}
		}
		else {push (@duration_cat, "slow");  # fast speaker with slow syllable
		}
	}
	else{ # fast syllable
		# print ">> This syllable is fast: dur = $syll_dur, Q3 is $syll_Q3\n";
		push (@duration_cat, "-");
	}}
}


# foreach $value (@duration_cat){   # Let's see if this can help at all ...
#	print "$value >> $syll_dur\n";
#}



####################################################################################
####################################################################################
### Add here:
# Duration as a factor
# H3 + resid-value extreme as a factor
# and a control
# perhaps only do this in the course of the evaluation?


### Determining possible prosodic phrases
$count = -1;
$length = @prosword;
#print $length;
foreach $el (@prosword){
	$count ++;
	# print ">> $count : $duration_cat[$count]";
	$acount = $count;
	$next = $prosword[$count+1];
	# The following criteria return an echo so one knows based on which one a decision was made
	# only enter a boundary if strong H with fall 
	if (($el =~ /\)/) && ($tones[$count] =~ /H4/)){
		# took out requirement that there need to be further H-tones
				splice @prosword, $count, 1, 'σ))pp';
				$next = $prosword[$count+1];
				splice @prosword, $count+1, 1, 'pp('.$next;  #this concatenates with the present value.
				print ">> A boundary was entered based on a H4 accent\n";
	}
	# Added if there is a High tone and th residual is surprising (= extreme)
	elsif (($el =~ /\)/) && ($tones[$count] =~ /H3/) && ($resids[$count] =~ /^surprise/)){  #resids only if extreme
				splice @prosword, $count, 1, 'σ))pp';
				$next = $prosword[$count+1];
				#print "the value of next is $next\n";
				splice @prosword, $count+1, 1, 'pp('.$next;
				print ">> A boundary was entered based on a H3 accent and a surprising residual\n";
	}
	# Added if there is a High tone H (any) and a long syllable at the target position
	elsif (($el =~ /\)/) && ($tones[$count] =~ /H/) && ($duration_cat[$count] eq "slow")){ 
				splice @prosword, $count, 1, 'σ))pp';
				$next = $prosword[$count+1];
				#print "the value of next is $next\n";
				splice @prosword, $count+1, 1, 'pp('.$next;
				print ">> A boundary was entered based on a H accent and a long syllable\n";
	}
	# This one added for if there is a pause --> that always conveys a dative
	elsif (($el =~ /\)/) && ($pause eq "y") && ($next = "-")){
				splice @prosword, $count, 1, 'σ))pp';
				$next = $prosword[$count+2];
				splice @prosword, $count+2, 1, 'pp('.$next;
				print ">> A boundary was entered based on a following pause\n";
				$pause = "n";
	}
	if ($count == 0){
		splice @prosword, $count, 1, 'pp(σ';
	}
	elsif ($count == ($length-1)){
		splice @prosword, $count, 1, 'σ))pp';
	}
}

#$int_count = 0;
#foreach $value (@values){
#$int_count++;
#print "$int_count +++ $value\n";
#}


### Print out the p-diagram
open(OUTPUT7, "> 4_p_diagram/p_diagram.txt");


&Create_pdiagram(\@prosword, "pros_phrase");
&Create_pdiagram(\@tones, "pitch_tones");
&Create_pdiagram(\@lexstress, "lex_stress");
&Create_pdiagram(\@F0mean, "FO_mean  ");
&Create_pdiagram(\@duration_cat, "Dur:cat   ");
&Create_pdiagram(\@duration, "duration  ");
&Create_pdiagram(\@values, "syllables");

sub Create_pdiagram {
	$category = $_[1]; 
	@array 	= @{$_[0]};
	print OUTPUT7 "\n$category\t";
	foreach $el (@array){
		print OUTPUT7 "$el\t";
	}
}

$count = 0;
# This following to adjust the divider line to the number of elements
$length = @values;
$individ = "---------" x $length;
$divider = "\n----------" . $individ ;
print OUTPUT7 $divider;

print OUTPUT7 "\nVector_index\t";
foreach $el (@values) {
	$count++;
	
	print OUTPUT7 "$count\t";
}

close(OUTPUT7);

print ">>> Done with 4_p_diagram\n";
print ">>> Press enter to continue\n";
$input = <STDIN>;

